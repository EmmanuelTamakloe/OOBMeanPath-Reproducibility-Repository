
import argparse
import time

import numpy as np
import torch

from deepod.models.tabular import DeepIsolationForest, SLAD


def sanitize(scores):
    scores = np.asarray(
        scores,
        dtype=float,
    ).reshape(-1)

    finite = np.isfinite(scores)

    if not finite.any():
        raise RuntimeError(
            "Model returned no finite anomaly scores."
        )

    hi = float(
        np.max(scores[finite])
    )
    lo = float(
        np.min(scores[finite])
    )

    return np.nan_to_num(
        scores,
        nan=0.0,
        posinf=hi,
        neginf=lo,
    )


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--method",
        required=True,
        choices=["DIF", "SLAD"],
    )
    parser.add_argument(
        "--input",
        required=True,
    )
    parser.add_argument(
        "--output",
        required=True,
    )
    parser.add_argument(
        "--seed",
        type=int,
        required=True,
    )

    args = parser.parse_args()

    X = np.asarray(
        np.load(args.input),
        dtype=np.float32,
    )

    seed = int(args.seed)

    np.random.seed(seed)
    torch.manual_seed(seed)

    if args.method == "DIF":
        model = DeepIsolationForest(
            n_ensemble=50,
            n_estimators=6,
            max_samples=min(256, len(X)),
            device="cpu",
            verbose=0,
            random_state=seed,
        )

    else:
        model = SLAD(
            epochs=100,
            batch_size=128,
            lr=0.001,
            hidden_dims=100,
            act="LeakyReLU",
            distribution_size=10,
            n_slad_ensemble=20,
            subspace_pool_size=50,
            magnify_factor=200,
            n_unified_features=128,
            epoch_steps=-1,
            prt_steps=10,
            device="cpu",
            verbose=0,
            random_state=seed,
        )

    t0 = time.perf_counter()

    model.fit(X)

    scores = sanitize(
        model.decision_function(X)
    )

    elapsed = time.perf_counter() - t0

    if len(scores) != len(X):
        raise RuntimeError(
            f"{args.method}: returned {len(scores)} scores "
            f"for {len(X)} observations."
        )

    np.savez_compressed(
        args.output,
        scores=scores,
        runtime_sec=np.asarray(
            [elapsed],
            dtype=float,
        ),
    )


if __name__ == "__main__":
    main()
